//
//  Isler.swift
//  toDoApp
//
//  Created by Berkay Güneş on 29.08.2022.
//

import Foundation

class Isler {
    var is_id:Int?
    var is_ad:String?
    
     init(is_id:Int,is_ad:String) {
        self.is_id = is_id
        self.is_ad = is_ad
    }
    
    
    
}
